﻿using ShubhamADO.DatabaseConnection;
using ShubhamADO.Models;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.DataAccess
{
    public class GuestDataAccess
    {
        DbConnection Db = new DbConnection();
        
        public List<PayingGuest> GetGuestList()
        {
            string sp1 = "SHOW_GUESTLIST";
            SqlCommand cmd = new SqlCommand(sp1,Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            if(Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            SqlDataReader reader = cmd.ExecuteReader();
            List<PayingGuest> Plst = new List<PayingGuest>();
            while(reader.Read())
            {
                PayingGuest PG = new PayingGuest();
                PG.ID = (int)reader[0];
                PG.GUEST_NAME = reader[1].ToString();
                PG.GUEST_AGE = (int)reader[2];
                PG.PHONE_NUMBER = reader[3].ToString();
                PG.GUEST_CURRENT_ADDRESS = reader[4].ToString();
                PG.GUEST_PARMANANT_ADDRESS = reader[5].ToString();
                Plst.Add(PG);
            }
            Db.sql.Close();
            return Plst;
        }
     
        public void CreateGuest(PayingGuest guest)
        {
            string sp2 = "ADD_GUEST";
            SqlCommand cmd = new SqlCommand(sp2,Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@GUEST_NAME", guest.GUEST_NAME);
            cmd.Parameters.AddWithValue("@GUEST_AGE", guest.GUEST_AGE);
            cmd.Parameters.AddWithValue("@PHONE_NUMBER", guest.PHONE_NUMBER);
            cmd.Parameters.AddWithValue("@GUEST_CURRENT_ADDRESS", guest.GUEST_CURRENT_ADDRESS);
            cmd.Parameters.AddWithValue("@GUEST_PARMANANT_ADDRESS", guest.GUEST_PARMANANT_ADDRESS);
            if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            cmd.ExecuteNonQuery();
            Db.sql.Close();
        }
        
        public PayingGuest GetById(int ID)
        {
            string sp4 = "GETBYID";
            SqlCommand cmd = new SqlCommand(sp4, Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            SqlDataReader reader = cmd.ExecuteReader();
            PayingGuest PG = new PayingGuest();
            if (reader.Read())
            {
                PG.ID = (int)reader[0];
                PG.GUEST_NAME = reader[1].ToString();
                PG.GUEST_AGE = (int)reader[2];
                PG.PHONE_NUMBER = reader[3].ToString();
                PG.GUEST_CURRENT_ADDRESS = reader[4].ToString();
                PG.GUEST_PARMANANT_ADDRESS = reader[5].ToString();
            }
            Db.sql.Close();
            return PG;
        }
        
        public void UpdateGuest(PayingGuest guest)
        {
            string sp3 = "UPDATE_GUEST";
            SqlCommand cmd = new SqlCommand(sp3, Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", guest.ID);
            cmd.Parameters.AddWithValue("@GUEST_NAME", guest.GUEST_NAME);
            cmd.Parameters.AddWithValue("@GUEST_AGE", guest.GUEST_AGE);
            cmd.Parameters.AddWithValue("@PHONE_NUMBER", guest.PHONE_NUMBER);
            cmd.Parameters.AddWithValue("@GUEST_CURRENT_ADDRESS", guest.GUEST_CURRENT_ADDRESS);
            cmd.Parameters.AddWithValue("@GUEST_PARMANANT_ADDRESS", guest.GUEST_PARMANANT_ADDRESS);
            if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            cmd.ExecuteNonQuery();
            Db.sql.Close();
        }

        public void DeleteGuest(int ID)
        {
            string sp5 = "DELETE_GUEST";
            SqlCommand cmd = new SqlCommand(sp5, Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ID", ID);
            if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            cmd.ExecuteNonQuery();
            Db.sql.Close();
        }
    }
}
