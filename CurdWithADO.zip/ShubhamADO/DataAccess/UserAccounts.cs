﻿using ShubhamADO.DatabaseConnection;
using ShubhamADO.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.DataAccess
{

    public class UserAccounts
    {
        DbConnection Db = new DbConnection();
        public string UserSignUp(UserUtility user)
        {
            string Otp = Utility.OtpUtility.GenrateOtp();
            string sp1 = "user_signup";
            SqlCommand cmd = new SqlCommand(sp1,Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserName", user.UserName);
            cmd.Parameters.AddWithValue("@Email", user.Email);
            cmd.Parameters.AddWithValue("@Gender", user.Gender);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            cmd.Parameters.AddWithValue("@Otp", Otp);

           if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            string message = string.Empty;
            if(dr.Read())
            {
                int exits = (int)dr["exist"];
                int created = (int)dr["created"];
                if(exits==1)
                {
                    message = "Exists";
                }
                else if(created==1)
                {
                    message = "Created";
                }
            }
            string body = $"<h2>Welcome dear.{user.UserName}</h2>";
            body += $"<p>Your registration is succesfull, Please verify your account.</p>";
            body += $"<p>Your verification code is {Otp} valid for 15 minute.</p>";
            body += $"<p>Thank You for Choosing us.</p>";
            //Utility.OtpUtility.SendEmail("dhimanshubham432@gmail.com", user.Email, "Account verification Email", body);
            Db.sql.Close();
            return message;
        }

        public int VerifyUser(string Otp)
        {
            string sp2 = "verifieduser";
            SqlCommand cmd = new SqlCommand(sp2, Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Otp", Otp);
            if (Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            int r=0;
            if (dr.Read())
            {
                r = (int)dr["Verified"];
            }
            Db.sql.Close();
            return r;
        }

        public string userlogin(Login login)
        {
            string sp3 = "login";
            SqlCommand cmd = new SqlCommand(sp3, Db.sql);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Email", login.Email);
            cmd.Parameters.AddWithValue("@Password", login.Password);
            if(Db.sql.State == ConnectionState.Closed)
            {
                Db.sql.Open();
            }
            SqlDataReader rd = cmd.ExecuteReader();
            string message = string.Empty;
            if(rd.Read())
            {
                int valid = (int)rd["valid"];
                int invalid = (int)rd["invalid"];
                if (valid == 1)
                {
                    message = "Valid";
                }
                else if (invalid == 1)
                {
                    message = "Invalid";
                }
            }
            Db.sql.Close();
            return message;
        }
    }
  
}
