﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.DatabaseConnection
{
    public class DbConnection
    {
        public SqlConnection sql { get; }
       public  DbConnection()
        {
            sql = new SqlConnection(connectionstring.connstr);
        }
    }
    public class connectionstring
    { 
       public static string connstr { get; set; }
    }

}
