﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.Models
{
    public class UserUtility
    {
        public int Id { get; set; }
        [Required]
        [Range(3,8,ErrorMessage="Enter name charcter between 3 to 8 long.")]
        public string UserName { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        [MinLength(8, ErrorMessage = "Password must be 8 charcter long.")]
        public string Password { get; set; }
        [Required]
        [Compare("Password",ErrorMessage="Password did't match.")]
        public string ConfirmPassword { get; set; }
    }
}
