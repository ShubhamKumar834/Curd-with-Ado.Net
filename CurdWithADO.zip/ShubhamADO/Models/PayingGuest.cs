﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.Models
{
    public class PayingGuest
    {
        [Key]
        public int ID { get; set; }

        [Required (ErrorMessage ="PLease enter name.")]
        [MinLength(5,ErrorMessage ="Please enter name with minimum 5 charcters.")]
        public string GUEST_NAME { get; set; }

        [Required(ErrorMessage = "PLease enter age.")]
        [Range(16,40,ErrorMessage ="Enter age between 16 to 40")]
        public int GUEST_AGE { get; set; }
        [Required(ErrorMessage = "PLease enter phone number.")]
        public string PHONE_NUMBER { get; set; }

        [Required(ErrorMessage = "PLease enter current address.")]
        [MaxLength(250,ErrorMessage ="Enter less than 250 charcters")]
        public string GUEST_CURRENT_ADDRESS { get; set; }

        [Required(ErrorMessage = "PLease enter paramanant address.")]
        [MaxLength(250, ErrorMessage = "Enter less than 250 charcters")]
        public string GUEST_PARMANANT_ADDRESS { get; set; }
    }
}
