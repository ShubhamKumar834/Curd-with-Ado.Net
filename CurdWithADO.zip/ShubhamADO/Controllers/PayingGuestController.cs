﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ShubhamADO.DataAccess;
using ShubhamADO.DatabaseConnection;
using ShubhamADO.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ShubhamADO.Controllers
{
    [Authorize]
    public class PayingGuestController : Controller
    {
        GuestDataAccess GuestData = new GuestDataAccess();
        public IActionResult ShowDataList()
        {
            var PData = GuestData.GetGuestList();
            return View(PData);
        }

        [HttpGet]
        public IActionResult CreateGuests()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddGuest(PayingGuest guest)
        {
            if (ModelState.IsValid)
            {
                var data = new PayingGuest();
                data.GUEST_NAME = Request.Form["GUEST_NAME"];
                string GUEST_AGE = Request.Form["GUEST_AGE"];
                if (!string.IsNullOrEmpty(GUEST_AGE))
                {
                    data.GUEST_AGE = Convert.ToInt32(Request.Form["GUEST_AGE"]);
                }
                data.PHONE_NUMBER = Request.Form["PHONE_NUMBER"];
                data.GUEST_CURRENT_ADDRESS = Request.Form["GUEST_CURRENT_ADDRESS"];
                data.GUEST_PARMANANT_ADDRESS = Request.Form["GUEST_PARMANANT_ADDRESS"];
                GuestData.CreateGuest(data);
                return RedirectToAction("ShowDataList");
            }
            else { return View("CreateGuests"); }
        }

        [HttpGet]
        public IActionResult EditG(int id)
        {
            var G = GuestData.GetById(id);
            return View(G);
        }

        [HttpPost]
        public IActionResult EditGuest()
        {
            var data = new PayingGuest();
            data.ID = Convert.ToInt32(Request.Form["ID"]);
            data.GUEST_NAME = Request.Form["GUEST_NAME"].ToString();
            data.GUEST_AGE = Convert.ToInt32(Request.Form["GUEST_AGE"]);
            data.PHONE_NUMBER = Request.Form["PHONE_NUMBER"];
            data.GUEST_CURRENT_ADDRESS = Request.Form["GUEST_CURRENT_ADDRESS"];
            data.GUEST_PARMANANT_ADDRESS = Request.Form["GUEST_PARMANANT_ADDRESS"];
            GuestData.UpdateGuest(data);
            return RedirectToAction("ShowDataList");
        }

        [HttpGet]
        public IActionResult Delete(int ID)
        {
            GuestData.DeleteGuest(ID);
            return RedirectToAction("ShowDataList");
        }
    }
}
