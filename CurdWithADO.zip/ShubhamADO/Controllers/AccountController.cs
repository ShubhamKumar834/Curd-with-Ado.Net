﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ShubhamADO.DataAccess;
using ShubhamADO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ShubhamADO.Controllers
{
    public class AccountController : Controller
    {
        UserAccounts account = new UserAccounts();
        
        [HttpGet]
         public IActionResult Login()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult UserLogin(Login logn)
        {
            if(ModelState.IsValid)
            {
                var res = account.userlogin(logn);
                string message = string.Empty;
                if(res == "Valid")
                {
                    var identity = new ClaimsIdentity(new[]{new Claim(ClaimTypes.Name, logn.Email)},                CookieAuthenticationDefaults.AuthenticationScheme);
                    var principle = new ClaimsPrincipal(identity);
                    HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principle);
                    HttpContext.Session.SetString("Email", logn.Email);
                   return RedirectToAction("ShowDataList", "PayingGuest");
                }
                else if(res == "Invalid")
                {
                    message = "Invalid User name and Password";
                }
                ViewBag.message = message;
            }
            return View("Login"); 
        }
       
       [HttpGet]
        public IActionResult register()
        {
            return View();
        }

       [HttpPost]
        public IActionResult registeruser(UserUtility user)
        {
            if(ModelState.IsValid)
            {
                string result = account.UserSignUp(user);
                
                if (result== "Exists")
                {
                    var e = "User allready exists with email address!";
                    ViewBag.message = e;
                    return View("register");
                }
                else if(result== "Created")
                {
                    return RedirectToAction("verify");
                }
            }
            return View();
        }

       [HttpGet]
        public IActionResult verify()
        {
            return View();
        }

        [HttpPost]
        public IActionResult verifyuser(string Otp)
        {
            if(!string.IsNullOrEmpty(Otp))
            {
                int x = account.VerifyUser(Otp);
                string message = string.Empty;
                switch(x)
                {
                    case 1:
                        message = "Your Account is verified successfully. Click on login to continuue Thank You.";
                        break;
                    case 2:
                        message = "Oops ! Time Out";
                        break;
                    case 3:
                        message = "Invalid Otp";
                        break;
                    default:
                        message = "Something went wrong.";
                        break;
                }
                ViewBag.message = message;
            }
            else
            {
                ViewBag.message = "please enter Otp.";
            }
            return View("verify");
        }

        public IActionResult Logout()
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            var storedCookies = Request.Cookies.Keys;
            foreach(var cookies in storedCookies)
            {
                Response.Cookies.Delete(cookies);
            }
            return RedirectToAction("Login","Account");
        }
    }
}
