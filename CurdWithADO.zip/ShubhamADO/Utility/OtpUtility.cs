﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ShubhamADO.Utility
{
    public class OtpUtility
    {
        public static string GenrateOtp()
        {
            Random r = new Random();
            var Otp = r.Next(1111, 9999);
            return Otp.ToString();
        }

        public static void SendEmail(string from, string to, string subject, string body)
        {
            MailMessage mail = new MailMessage(from, to);
            mail.Subject = subject;
            mail.IsBodyHtml = true;
            mail.Body = body;
            var smtp = new SmtpClient
            {
                Host = "smtp.mailtrap.io",
                Port = 2525,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("a3c15a4b965cc5", "84511f470b0f8e"),
                EnableSsl = true,
            };
            smtp.Send(mail);
        }
    }
}
